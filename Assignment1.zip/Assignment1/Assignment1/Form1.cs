﻿// ASSIGNMENT 1 
// COURSE: PRO670 
// PROFESSOR:SORIN GABRIEL BUTNARU
// STUDENT: OLEH IVANYSHYN
// STUDENT ID:125165167
// DATE: 2019-06-25

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    
    public partial class Form1 : Form
    {   
        //List xList of type string 
        List<string> xList = new List<string>();
        
        public Form1()
        {
            InitializeComponent();
            

        }
    
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // check if both name and phone has been inputted and add it to the listbox

            

            if (string.IsNullOrEmpty(txtName.Text) && string.IsNullOrEmpty(txtPhone.Text))
            {
                return;
            }
           
                 lbPersons.Items.Add(txtName.Text + " " + txtPhone.Text);

            txtName.Clear();
            txtPhone.Clear();

            // set visible when listbox has at least 1 item

            if (lbPersons.Items.Count > 0)
            {
                btnStart.Visible = true;
                ckBkg.Visible = true;
               
              
            }
        }

        

        private void BtnExit_Click(object sender, EventArgs e)
        {
            // close the program when exit button pressed
            this.Close();
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
            // Delete selected by user row 
            if (lbPersons.Items.Count > 0) {
                lbPersons.Items.Remove(lbPersons.SelectedItem);
            }
            else
            {
                // Error when condition is not met
                lblErrors.Visible = true;
                lblErrors.BackColor = Color.Red;
           
            }
                
        }

        private void TxtName_TextChanged(object sender, EventArgs e)
        {
            // set add button visible when name and phone entered
            this.btnAdd.Visible = !string.IsNullOrWhiteSpace(this.txtName.Text) && !string.IsNullOrWhiteSpace(this.txtPhone.Text);
        }

        private void TxtPhone_TextChanged(object sender, EventArgs e)
        {
            // set add button visible when name and phone entered
            this.btnAdd.Visible = !string.IsNullOrWhiteSpace(this.txtName.Text) && !string.IsNullOrWhiteSpace(this.txtPhone.Text);
        }

        public void LbPersons_SelectedIndexChanged(object sender, EventArgs e)
        {
            // set visible button delete when there is at least 1 contact in the list, NOTE: Button will be visible only when you select the row to delete
            if (lbPersons.Items.Count > 0)
                btnDel.Visible = true;
           

        }



        private void ComboCols_SelectedIndexChanged(object sender, EventArgs e)
        {
            // adding color items to the column
        
        }

        private void CkBkg_CheckedChanged(object sender, EventArgs e)
        {
            // enable to choose backgroud color when color change checkbox is enabled
            if (ckBkg.Checked)
            {
                comboCols.Visible = true;
            }
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            // opens a new form when button "start" is clicked

        if (comboCols.SelectedItem == null)
            {
                lblErrors.Text = "Please select Color";
                lblErrors.Visible = true;
            } else {
                Form2 f2 = new Form2((string)comboCols.SelectedItem, lbPersons);
                f2.ShowDialog();
            }
        }
    
    }
}
