﻿// ASSIGNMENT 1 
// COURSE: PRO670 
// PROFESSOR:SORIN GABRIEL BUTNARU
// STUDENT: OLEH IVANYSHYN
// STUDENT ID:125165167
// DATE: 2019-06-25

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    public partial class Form2 : Form
    {
        //creating list myL of type string
        private List<string> myL = new List<string>();


        public Form2(string value, ListBox listBox)
        {
            InitializeComponent();
            this.BackColor = Color.FromName(value);
            // Add text from xList to a myL, no duplicate values
            foreach (string item in listBox.Items)
            {
                if (!myL.Contains(item))
                {
                    myL.Add(item);
                }
            }

            // Read file myPersons, no duplicate values
            try
            {
                string[] lines = File.ReadAllLines(@"D\MyPersons.txt");
                foreach (string item in lines)
                {
                    if (!myL.Contains(item))
                    {
                        myL.Add(item);
                    }
                }
                lblMessage.Text = "Success";
                lblMessage.Visible = true;
            }
            catch
            {
                lblMessage.Text = "No file has found";
                lblMessage.Visible = true;
            }



            //myL list population
            foreach (string item in myL)
            {
                listBoxReceive.Items.Add(item);
            }
        }

        

        private void BtnSave_Click(object sender, EventArgs e)
        {
            // Storing the info into the file MyPersons.txt
            if (listBoxReceive.Items.Count > 0)
            {
                using (TextWriter TW = new StreamWriter("MyPersons.txt"))
                {
                    foreach (string itemText in listBoxReceive.Items)
                    {
                        TW.WriteLine(itemText);
                    }
                }
                Process.Start("MyPersons.txt");
            }

            Application.Exit();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}